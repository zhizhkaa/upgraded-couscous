package com.example;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.util.Arrays;
import java.util.Collection;

@RunWith(Parameterized.class)
public class MyUtilsTestParameterized {
    String str;
    int count;

    public MyUtilsTestParameterized(String str, int count) {
        this.str = str;
        this.count = count;
    }

    @Parameterized.Parameters
    public static Collection<Object[]> data(){
        return Arrays.asList(new Object[][]{
                {"00000", 0},
                {"11111", 0},
                {"00122", 2},
                {"22222", 5},
                {"12345", 4}
        });
    }
    @Test
    public void testSum(){
        MyUtils myUtils = new MyUtils();
        Assert.assertEquals(count, myUtils.countOtherDigits(str));
    }
}
