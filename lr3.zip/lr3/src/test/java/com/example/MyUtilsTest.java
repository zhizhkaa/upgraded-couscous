package com.example;

import org.junit.Assert;

import org.junit.BeforeClass;
import org.junit.Test;

public class MyUtilsTest {

    static MyUtils myUtils;

    @BeforeClass
    public static void setUpOutputStream(){
        myUtils = new MyUtils();
    }

    @Test
    public void testCountOtherDigitsPositive() {
        Assert.assertEquals(0, myUtils.countOtherDigits("0"));
        Assert.assertEquals(0, myUtils.countOtherDigits("1"));
        Assert.assertEquals(0, myUtils.countOtherDigits("10101010"));
        Assert.assertEquals(6, myUtils.countOtherDigits("10000512340203"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCountOtherDigitsNegative() {
        myUtils.countOtherDigits("abcdefg");
        myUtils.countOtherDigits("10001abcdefg");
    }

    @Test
    public void testFindMaxInArraysPositive() {
        int[] arr1 = {1, 2, 3};
        int[] arr2 = {4, 5, 6};
        Assert.assertEquals(6, myUtils.findMaxInArrays(arr1, arr2));

        int[] arr3 = {10, 8, 3};
        int[] arr4 = {4, 2, 1};
        Assert.assertEquals(10, myUtils.findMaxInArrays(arr3, arr4));
    }

    @Test(expected = NullPointerException.class)
    public void testFindMaxInArraysNull() {
        int[] arr1 = null;
        int[] arr2 = null;
        myUtils.findMaxInArrays(arr1, arr2);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testFindMaxInArraysIllegalArgument() {
        int[] arr1 = {};
        int[] arr2 = {};
        myUtils.findMaxInArrays(arr1, arr2);
    }
    
}
