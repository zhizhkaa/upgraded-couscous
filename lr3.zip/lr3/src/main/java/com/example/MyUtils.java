package com.example;

public class MyUtils {

    public MyUtils() { }

    public int countOtherDigits(String input) throws IllegalArgumentException {
        int count = 0;

        for (int i = 0; i < input.length(); i++) {
            char currentChar = input.charAt(i);
    
            if (!Character.isDigit(currentChar))
                throw new IllegalArgumentException("Invalid character: " + currentChar);

            if (currentChar != '0' && currentChar != '1')
                count++;
        }
        return count;
    }

    public int findMaxInArrays(int[] arr1, int[] arr2) throws IllegalArgumentException, NullPointerException {
        int max1 = Integer.MIN_VALUE;
        int max2 = Integer.MIN_VALUE;

        if (arr1 == null || arr2 == null)
            throw new NullPointerException("Arrays can't be null");
        if (arr1.length == 0 || arr2.length == 0)
            throw new IllegalArgumentException("Arrays must not be empty");

        for (int i : arr1)
            max1 = Math.max(max1, i);
        for (int i : arr2)
            max2 = Math.max(max2, i);

        return Math.max(max1, max2);
    }
}